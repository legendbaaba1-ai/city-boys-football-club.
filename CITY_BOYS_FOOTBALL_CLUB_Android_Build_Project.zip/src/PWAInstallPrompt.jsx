import React, { useEffect, useState } from 'react';
import { Download, X, Share, Smartphone } from 'lucide-react';

export default function PWAInstallPrompt() {
  const [installEvent, setInstallEvent] = useState(null);
  const [showIOS, setShowIOS] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    if (isStandalone) setInstalled(true);
    const onBeforeInstall = (event) => { event.preventDefault(); setInstallEvent(event); };
    const onInstalled = () => { setInstalled(true); setInstallEvent(null); };
    window.addEventListener('beforeinstallprompt', onBeforeInstall);
    window.addEventListener('appinstalled', onInstalled);
    const ios = /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !isStandalone;
    setShowIOS(ios);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  if (installed || dismissed || (!installEvent && !showIOS)) return null;
  const install = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    await installEvent.userChoice;
    setInstallEvent(null);
  };

  return (
    <aside className="pwa-install-card" aria-label="Install CITY BOYS app">
      <div className="pwa-install-icon"><Smartphone size={22}/></div>
      <div className="pwa-install-copy">
        <strong>Ku rakib CITY BOYS app</strong>
        <span>{showIOS ? <>Riix <Share size={13} style={{display:'inline',verticalAlign:'middle'}}/> Share, kadib <b>Add to Home Screen</b>.</> : 'Ku rakib app-ka telefoonkaaga si fudud.'}</span>
      </div>
      {installEvent && <button className="pwa-install-button" onClick={install}><Download size={15}/> Install</button>}
      <button className="pwa-close-button" aria-label="Xir" onClick={() => setDismissed(true)}><X size={17}/></button>
    </aside>
  );
}
