// Firebase Functions client. This is loaded only for admin actions.
import {getFunctions} from 'firebase/functions';
import {auth} from './firebase';
export const functions = auth ? getFunctions(auth.app) : null;