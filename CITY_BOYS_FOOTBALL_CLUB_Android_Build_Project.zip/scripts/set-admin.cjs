// Run locally with a Firebase Admin service-account JSON file.
// Never upload the service-account file to Netlify or commit it to Git.
const admin=require('firebase-admin');
const path=require('path');
const keyPath=process.env.GOOGLE_APPLICATION_CREDENTIALS;
const email=process.argv[2];
const allowedEmail='ccaliaxmedxasan78@gmail.com';
if(!keyPath||!email){console.error('Isticmaal: GOOGLE_APPLICATION_CREDENTIALS=/secure/service-account.json node scripts/set-admin.cjs admin@email.com');process.exit(1);}
if(email.toLowerCase()!==allowedEmail){console.error('Email-kan looma oggola admin.');process.exit(1);}
admin.initializeApp({credential:admin.credential.cert(require(path.resolve(keyPath)))});
(async()=>{const u=await admin.auth().getUserByEmail(email);await admin.auth().setCustomUserClaims(u.uid,{...(u.customClaims||{}),admin:true});console.log('Admin permission granted to',email);process.exit(0);})().catch(e=>{console.error(e);process.exit(1);});