# CITY BOYS AC — Website

Website responsive ah oo Af-Soomaali ku qoran, leh muuqaal cad (white) iyo casaan (red), kana shaqeeya telefoon iyo computer.

## Waxa ku jira
- Login iyo diiwaangelin Firebase Authentication (email/password), iyo Forgot Password oo email reset link dira.
- Xogta ciyaaryahanka Firestore; sawirka profile-ka Firebase Storage.
- Menu-ga ciyaaryahanka: Home, Account, Funaanado.
- Saddex naqshadood oo funaanad ah; midkiiba $6 USD; cabbir, tiro iyo wadarta si toos ah loo xisaabiyo.
- Dalabku wuxuu ku bilaabmaa `pending`; maamulka ayaa aqbali/diidi kara marka uu xaqiijiyo lacag-bixinta.
- Admin dashboard-ka waxaa arki kara oo keliya account leh Firebase custom claim `admin: true`.
- Firestore/Storage Security Rules, Cloud Functions iyo Netlify redirect.

## 1. Firebase dejintiisa
1. Samee Firebase project: https://console.firebase.google.com/
2. Daar **Authentication → Email/Password**.
3. Samee **Firestore Database** iyo **Storage**.
4. Firebase Project Settings → Your apps → Web app, ka soo qaado config.
5. Firebase config-ga project-ka `city-boys-ac` hore ayaa loogu geliyey faylka `.env` ee ZIP-kan. Haddii aad beddesho Firebase project, cusboonaysii qiimayaasha halkaas.
6. Firebase CLI ku rakib: `npm install -g firebase-tools`, kadib `firebase login` iyo `firebase use YOUR_PROJECT_ID`.
7. Ku rakib packages: `npm install`.
8. Rules-ka dir: `firebase deploy --only firestore:rules,storage`.
9. Cloud Functions dir: `cd functions && npm install && cd .. && firebase deploy --only functions`.
10. Bilow: `npm run dev`; dhis: `npm run build`.

## 2. Sida admin loo sameeyo (MUHIIM)
Diiwaangeli account-ka admin-ka adigoo isticmaalaya website-ka. Kadib kombiyuutar ammaan ah, samee Firebase service-account key oo ha gelin Git/Netlify:
```bash
npm install firebase-admin
GOOGLE_APPLICATION_CREDENTIALS=/secure/service-account.json node scripts/set-admin.cjs admin@email.com
```
Kadib admin-ka ha ka baxo oo dib ha u soo galo. Claim-ka `admin:true` waxaa dejinaya Firebase Admin SDK oo keliya. **Ha ku darin service-account JSON ama private key frontend-ka.**

## 3. Netlify deployment
1. GitHub ku geli project-ka adigoo aan ku darin `.env` ama service-account key.
2. Netlify → Add new site → Import from Git.
3. Build command: `npm run build`; Publish directory: `dist`.
4. Netlify Site configuration → Environment variables, ku dar dhammaan `VITE_FIREBASE_...` values.
5. Deploy. Haddii env variables la beddelo, dib u deploy garee.

## 4. Lacag-bixinta EVC Plus
- Bogga dalabka wuxuu furaa USSD-ga `*712*610311612*6#` marka tiradu tahay hal funaanad ($6). Haddii tiradu badan tahay, lacagta USSD-ga waxaa loo waafajiyaa wadarta dalabka.
- Macmiilku wuxuu gelinayaa lambarka EVC Plus ee uu ka bixiyay iyo Transaction ID-ga ku jira SMS-ka xaqiijinta.
- Dalabku wuxuu ahaanayaa `pending`. Maamulka waa inuu ka hubiyaa lacagta/Transaction ID-ga diiwaanka EVC Plus ka hor inta uusan aqbalin.
- **Isku-xir toos ah oo API/auto-verification ah lama samayn**: taas waxay u baahan tahay marin ganacsi/API rasmi ah iyo credentials ka yimaada adeeg-bixiyaha. Hadda verification-ku waa mid maamulka gacanta ku xaqiijinayo.
- Website-ku marnaba ma weydiiyo mana kaydiyo PIN-ka ama sirta EVC Plus. Ha ka codsan ciyaartoyda PIN-kooda.

## 5. Amniga
- Ciyaaryahan wuxuu akhrin/kordhin karaa oo keliya profile-kiisa; ma beddeli karo UID/email ama role.
- Player ma akhrin karo xogta ciyaartoy kale.
- Dalabka ciyaaryahanka waa la abuuri karaa iyadoo xaaladdu tahay pending; beddelka status-ka waxaa loo xilsaaray admin.
- Admin dashboard UI-ga waxaa muujiya custom claim; Firestore rules iyo Cloud Functions ayaa mar kale xaqiijiya claim-ka.
- Rules-ku waa bilow adag, balse ka hor adeegsi rasmi ah ku tijaabi Firebase Emulator Suite, kuna dar App Check, email verification, habka xogta/ogolaanshaha ee kooxda. Forgot Password wuxuu adeegsadaa Firebase sendPasswordResetEmail; hubi Firebase Authentication → Templates → Password reset iyo authorized domains.

## Fiiro gaar ah
Firebase Web config-ga project-ka `city-boys-ac` waa lagu daray `.env`. Web API key-ga Firebase waa client config; ha ku darin service-account private key ama secrets kale frontend-ka. Website-ku ma laha account demo ama xog ciyaartoy oo been abuur ah.
