const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {initializeApp} = require('firebase-admin/app');
const {getAuth} = require('firebase-admin/auth');
const {getFirestore, FieldValue} = require('firebase-admin/firestore');
initializeApp();
const db=getFirestore();
const ADMIN_EMAIL='ccaliaxmedxasan78@gmail.com';
function adminOnly(req){if(!req.auth || req.auth.token.admin!==true || (req.auth.token.email||'').toLowerCase()!==ADMIN_EMAIL) throw new HttpsError('permission-denied','Email-kan oo keliya ayaa maamulka geli kara.');}
exports.adminSetOrderStatus=onCall(async req=>{
 adminOnly(req);
 const {orderId,status}=req.data||{};
 if(typeof orderId!=='string'||!['approved','rejected'].includes(status)) throw new HttpsError('invalid-argument','Xogta dalabka sax ma aha.');
 const r=db.collection('orders').doc(orderId);const snap=await r.get();
 if(!snap.exists)throw new HttpsError('not-found','Dalabka lama helin.');
 await r.update({status,reviewedAt:FieldValue.serverTimestamp(),reviewedBy:req.auth.uid});
 return {ok:true};
});
exports.adminSetPlayerActive=onCall(async req=>{
 adminOnly(req);
 const {uid,active}=req.data||{};
 if(typeof uid!=='string'||typeof active!=='boolean')throw new HttpsError('invalid-argument','Xog khaldan.');
 await getAuth().updateUser(uid,{disabled:!active});
 await db.collection('players').doc(uid).update({active});
 return {ok:true};
});